@echo off
setlocal
if "%~1"=="" (
 echo Usa Abrir CMD en el boton IAX del menu de pausa.
 pause
 exit /b 2
)
"%~dp0python.exe" -X utf8 "%~dp0main.py" --bridge "%~1"
if errorlevel 1 pause
